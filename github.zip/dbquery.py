import sqlite3

class Database:

    def __init__(self,aipdata):
        self.conn=sqlite3.connect("aipdata")
        self.cur=self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS tb_data(Sr_no INTEGER PRIMARY KEY, Name text,Invoicenumber INTEGER , gstnumber integer,amount integer)")
        self.conn.commit()
    def insert(self,Name,Invoicenumber,gstnumber,amount):
        self.cur.execute("INSERT INTO tb_data VALUES(NULL,?,?,?,?)",(Name,Invoicenumber,gstnumber,amount))
        self.conn.commit()
    def view(self):
        self.cur.execute("SELECT * FROM tb_data")
        rows=self.cur.fetchall()
        return rows
    def search(self,Name="",Invoicenumber="",gstnumber="",amount=""):
        self.cur.execute("SELECT * FROM tb_data WHERE Name=? OR Invoicenumber=? OR gstnumber=? OR amount=?",(Name,Invoicenumber,gstnumber,amount))
        rows=self.cur.fetchall()
        return rows
    def delete(self,sr_no):
        self.cur.execute("DELETE from tb_data WHERE sr_no=?",(sr_no,))
        self.conn.commit()
    def update(self,sr_no,Name,Invoicenumber,gstnumber,amount):
        self.cur.execute("UPDATE tb_data SET Name=?,Invoicenumber=?,gstnumber=?,amount=? WHERE sr_no=?",(Name,Invoicenumber,gstnumber,amount))
        self.conn.commit()
    def __del__(self):
        self.conn.close()
